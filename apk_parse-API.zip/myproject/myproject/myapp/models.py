# -*- coding: utf-8 -*-
from django.db import models

class Document(models.Model):
    package_name = models.CharField(max_length = 20)
    package_version_code = models.IntegerField()
    docfile = models.FileField(upload_to='documents/%Y/%m/%d')
