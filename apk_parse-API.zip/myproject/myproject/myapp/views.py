# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.http import HttpResponseRedirect,HttpResponse
from django.core.urlresolvers import reverse
from django.views.decorators.csrf import csrf_exempt

from myapp.models import Document
from myapp.forms import DocumentForm
from myapp.apk import APK

def list(request):
    # Handle file upload
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            apk_file = request.FILES['docfile']
            apk_file_name = str(apk_file.name )
            apk_file_read = apk_file.read()
            temp_apk_file = open("%s%s"%("C:/Users/Chand/Desktop/",apk_file_name),"w")
            temp_apk_file.write(apk_file_read)
            temp_apk_file.close()
            apkf = APK(str("C:/Users/Chand/Desktop/"+apk_file_name))
            package = apkf.package
            androidversion_code =  apkf.get_androidversion_code()
            resp = {"package":str(package),
                        "androidversion_code":str(androidversion_code),
            }
            print ("resp>>>>>",resp)
 
            newdoc = Document(package_name=str(package), package_version_code=str(androidversion_code))
            newdoc.save()

            # Redirect to the document list after POST
            return HttpResponseRedirect(reverse('myapp.views.list'))
    else:
        form = DocumentForm() # A empty, unbound form

    # Load documents for the list page
    documents = Document.objects.all()

    # Render list page with the documents and the form
    return render_to_response(
        'myapp/list.html',
        {'documents': documents, 'form': form},
        context_instance=RequestContext(request)
    )

